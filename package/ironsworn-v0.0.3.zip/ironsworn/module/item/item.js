export class IronswornItem extends Item {
}
