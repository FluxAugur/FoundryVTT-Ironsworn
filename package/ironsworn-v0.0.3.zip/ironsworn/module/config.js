export const Ironsworn = {
    momentum: [
        10, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0, -1, -2, -3, -4, -5, -6
    ],
    health: [
        5, 4, 3, 2, 1, 0
    ],
    spirit: [
        5, 4, 3, 2, 1, 0
    ],
    supply: [
        5, 4, 3, 2, 1, 0
    ],
    rank: [
        'troublesome',
        'dangerous',
        'formidable',
        'extreme',
        'epic'
    ],
    pathType: [
        'companion',
        'path',
        'combatTalent',
        'ritual'
    ]
};
